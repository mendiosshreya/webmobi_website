// scroll function changes navbar
$(document).ready(function(){
    /*$("#main").scroll(function(){
    	alert("scroll");
        $(".navbar-default").css("background-color","white");
        $(".navbar-default").css("top","0%");
    });*/
    $(window).scroll(function()
	   {
	       handleTopNavAnimation();
	   });

    $("#circle1").hover(function(){
      $("#circle_head").hide();
      $("#circle_text").show();
      $("#circle1").css("background-color","rgba(37,177,277,1)");
      $("#circle1").css("transition","0.5s ease");
    },function(){
      $("#circle_head").show();
      $("#circle_text").hide();
      $("#circle1").css("background-color","rgba(37,177,277,0.5)");
    })
    $("#circle2").hover(function(){
      $("#circle_head2").hide();
      $("#circle_text2").show();
      $("#circle2").css("background-color","rgba(37,177,277,1)");
      $("#circle2").css("transition","0.5s ease");
    },function(){
      $("#circle_head2").show();
      $("#circle_text2").hide();
      $("#circle2").css("background-color","rgba(37,177,277,0.5)");
    })
    $("#circle3").hover(function(){
      $("#circle_head3").hide();
      $("#circle_text3").show();
      $("#circle3").css("background-color","rgba(37,177,277,1)");
      $("#circle3").css("transition","0.5s ease");
    },function(){
      $("#circle_head3").show();
      $("#circle_text3").hide();
      $("#circle3").css("background-color","rgba(37,177,277,0.5)");
    })
    $("#circle4").hover(function(){
      $("#circle_head4").hide();
      $("#circle_text4").show();
      $("#circle4").css("background-color","rgba(37,177,277,1)");
      $("#circle4").css("transition","0.5s ease");
    },function(){
      $("#circle_head4").show();
      $("#circle_text4").hide();
      $("#circle4").css("background-color","rgba(37,177,277,0.5)");
    })
});
$(window).load(function()
 {
   handleTopNavAnimation();
 });
function handleTopNavAnimation() 
   {

       var top=$(window).scrollTop();
       if(top>10)
       {
	   	//alert("scroll");
           $('#mainNavigation').addClass('navbar-solid'); 
       }
       else
       {
           $('#mainNavigation').removeClass('navbar-solid'); 
       }
   }